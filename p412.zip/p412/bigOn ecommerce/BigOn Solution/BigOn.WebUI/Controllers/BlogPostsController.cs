﻿using Microsoft.AspNetCore.Mvc;

namespace BigOn.WebUI.Controllers
{
    public class BlogPostsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
