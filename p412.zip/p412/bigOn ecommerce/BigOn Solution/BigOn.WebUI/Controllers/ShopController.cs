﻿using Microsoft.AspNetCore.Mvc;

namespace BigOn.WebUI.Controllers
{
    public class ShopController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
