﻿using BigOn.WebUI.Models.DataContexts;
using BigOn.WebUI.Models.Entities;
using Microsoft.AspNetCore.Mvc;

namespace BigOn.WebUI.Controllers
{
    public class HomeController : Controller
    {
        private readonly BigOnDbContext dbContext;

        public HomeController(BigOnDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Contact(ContactPost contactModel)
        {
            dbContext.ContactPosts.Add(contactModel);
            dbContext.SaveChanges();
            TempData["message"] ="muracietiniz qebul edildi";
            return RedirectToAction(nameof(Contact));
        }
    }
}
