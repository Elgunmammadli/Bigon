﻿using BigOn.WebUI.Models.DataContexts.Configurations;
using BigOn.WebUI.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace BigOn.WebUI.Models.DataContexts
{
    public class BigOnDbContext : DbContext
    {
        public BigOnDbContext(DbContextOptions options)
            :base(options)
        {

        }

        public DbSet<Brand> Brands { get; set; }
        public DbSet<ProductColor> Colors { get; set; }
        public DbSet<ProductSize> Sizes { get; set; }
        public DbSet<ProductMaterial> Materials { get; set; }
        public DbSet<ProductType> Types { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<ContactPost> ContactPosts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(BigOnDbContext).Assembly);
        }
    }
}
