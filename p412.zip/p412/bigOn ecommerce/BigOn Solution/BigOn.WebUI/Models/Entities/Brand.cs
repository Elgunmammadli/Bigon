﻿using BigOn.WebUI.AppCode.Infrastructure;
using System;

namespace BigOn.WebUI.Models.Entities
{
    public class Brand : BaseEntity
    {

        public string Name { get; set; }

    }
}
