﻿using BigOn.WebUI.AppCode.Infrastructure;
using System;

namespace BigOn.WebUI.Models.Entities
{
    public class ProductColor : BaseEntity
    {
       
        public string Name { get; set; }
        public string HexCode { get; set; }
    }
}
