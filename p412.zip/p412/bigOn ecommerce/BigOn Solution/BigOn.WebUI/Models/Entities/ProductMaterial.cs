﻿using BigOn.WebUI.AppCode.Infrastructure;

namespace BigOn.WebUI.Models.Entities
{
    public class ProductMaterial : BaseEntity
    {
        public string Name { get; set; }
    }
}
