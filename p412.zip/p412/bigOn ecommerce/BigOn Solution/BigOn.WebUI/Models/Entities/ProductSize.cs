﻿using BigOn.WebUI.AppCode.Infrastructure;
using System;

namespace BigOn.WebUI.Models.Entities
{
    public class ProductSize : BaseEntity
    {
        public string Name { get; set; }
        public string ShortName { get; set; }
    }
}
